from random import random

n = 10
x = [0]*n
ch = []
for i in range(n):
    x[i] = int(random() * 10) + 10
    if x[i] % 2 == 0:
        ch.append(i)
print(x)
print(f'Индексы четных элементов: {ch}!')