# 2. Закодируйте любую строку по алгоритму Хаффмана.

thestr = "zemlia smerdit do samix zvezd"

freq = {}
for char in thestr:
    if char not in freq:
        freq[char] = 0
    freq[char] += 1
print(freq)
tree = freq.items()
print(tree)

class MyNode:
    def __init__(self, left=None, right=None):
        # self.data = data
        self.left = left
        self.right = right

    def children(self):
        return self.left, self.right


def haffman(node, code=""):
    if isinstance(node, str):
        return {node: code}

    lef, rig = node.children()

    res = {}
    res.update(haffman(lef, code + "0"))
    res.update(haffman(rig, code + "1"))

    return res


while len(tree) > 1:
    tree = sorted(tree, reverse=True, key=lambda x: x[1])
    ch1, cnt1 = tree[-1]
    ch2, cnt2 = tree[-2]
    tree = tree[:-2]
    tree.append((MyNode(ch1, ch2), cnt1 + cnt2))

codeTab = haffman(tree[0][0])
coded = []
for char in thestr:
    coded.append(codeTab[char])

print("Исходная строка: " + thestr)
print(f"Закодированная строка: {' '.join(coded)}")
